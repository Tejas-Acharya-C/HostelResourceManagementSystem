package service;

import dao.*;
import model.Booking;

import java.sql.Connection;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Service Layer: Handles the business logic for bookings.
 * Responsible for Transaction Management (ACID properties).
 */
public class BookingService {

    /**
     * Attempts to book a resource. Checks capacity vs active bookings before confirming.
     */
    public void bookResource(int userId, int resourceId,
                             LocalDateTime start, LocalDateTime end) {

        try {
            // 1. Establish a single connection for the whole transaction
            Connection conn = DBConnection.getConnection();

            // 2. Disable Auto-Commit: Only save changes if ALL steps succeed
            conn.setAutoCommit(false);

            BookingDAO bookingDAO = new BookingDAO();
            ResourceDAO resourceDAO = new ResourceDAO();

            // Step 1: Get total capacity (e.g., 5 washing machines)
            int capacity = resourceDAO.getCapacity(resourceId);

            // Step 2: Count how many are currently booked in this time slot
            // We pass 'conn' to ensure we use the same DB session
            int activeCount = bookingDAO.countActiveBookings(
                    resourceId,
                    Timestamp.valueOf(start),
                    Timestamp.valueOf(end),
                    conn);

            System.out.println("Active bookings: " + activeCount +
                               " / Capacity: " + capacity);

            // Step 3: Compare Active vs Capacity
            if (activeCount < capacity) {
                // Spot available -> Create Booking
                Booking b = new Booking();
                b.userId = userId;
                b.resourceId = resourceId;
                b.startTime = start;
                b.endTime = end;
                b.status = "CONFIRMED";

                bookingDAO.createBooking(b, conn);
                System.out.println("Booking CONFIRMED");
            } else {
                // No spots available
                System.out.println("Booking REJECTED (capacity full)");
            }

            // 4. Commit transaction (Save changes permanently)
            conn.commit();

            // 5. Close connection
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            // In a real app, you would add conn.rollback() here
        }
    }
}