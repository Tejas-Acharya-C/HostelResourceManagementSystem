package model;

/**
 * Represents a physical resource (e.g., Washing Machine, Study Room).
 * Corresponds to the 'resources' table.
 */
public class Resource {
    // Unique ID (Primary Key)
    public int resourceId;

    // Name of the resource (e.g., "Washing Machine A")
    public String resourceName;

    // Maximum number of simultaneous users allowed
    public int capacity;
}