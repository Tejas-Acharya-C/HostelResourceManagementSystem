package model;

import java.time.LocalDateTime;

/**
 * Represents a specific reservation of a resource.
 * Corresponds to the 'bookings' table.
 */
public class Booking {
    public int bookingId;
    public int userId;
    public int resourceId;

    // Java 8 Date-Time API for easier manipulation than java.util.Date
    public LocalDateTime startTime;
    public LocalDateTime endTime;

    // Status: 'CONFIRMED', 'CANCELLED', 'PENDING'
    public String status;
}