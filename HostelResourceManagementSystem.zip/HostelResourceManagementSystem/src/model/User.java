package model;

/**
 * Represents a registered user in the system.
 * Corresponds to the 'users' table in the database.
 */
public class User {
    // Unique ID for the user (Primary Key)
    public int userId;

    // User's full name
    public String name;

    // Role: 'STUDENT', 'WARDEN', etc. determines permissions/priority
    public String role;

    // Priority score used for conflict resolution (higher = more priority)
    public int priorityScore;

    // Accumulated penalty points for bad behavior (cancellations/no-shows)
    public int penaltyPoints;
}