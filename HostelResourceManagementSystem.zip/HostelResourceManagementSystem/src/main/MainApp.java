package main;

import java.time.LocalDateTime;
import java.util.Scanner;

import dao.ResourceDAO;
import dao.UserDAO;
import model.Resource;
import model.User;
import service.BookingService;

/**
 * Main application entry point.
 * Provides a Command Line Interface (CLI) for users to interact with the system.
 */
public class MainApp {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        // Main Loop: Keeps program running until user chooses Exit
        while (true) {
            System.out.println("\n===== HOSTEL RESOURCE MANAGEMENT SYSTEM =====");
            System.out.println("1. Create User");
            System.out.println("2. Create Resource");
            System.out.println("3. Book Resource");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    createUser();
                    break;
                case 2:
                    createResource();
                    break;
                case 3:
                    bookResource();
                    break;
                case 4:
                    System.out.println("Program terminated.");
                    System.exit(0); // Standard successful exit
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    // -------- CREATE USER --------
    static void createUser() {
        try {
            sc.nextLine(); // Consume the newline left over from sc.nextInt()
            System.out.print("Enter name: ");
            String name = sc.nextLine();

            System.out.print("Enter role (STUDENT/WARDEN): ");
            String role = sc.nextLine();

            User u = new User();
            u.name = name;
            u.role = role.toUpperCase();
            // Logic: Wardens get higher priority score automatically
            u.priorityScore = role.equalsIgnoreCase("WARDEN") ? 50 : 10;
            u.penaltyPoints = 0; // New users start with 0 penalties

            new UserDAO().createUser(u);
            System.out.println("User created successfully.");

        } catch (Exception e) {
            System.out.println("Error creating user.");
        }
    }

    // -------- CREATE RESOURCE --------
    static void createResource() {
        try {
            sc.nextLine(); // Clear buffer
            System.out.print("Enter resource name: ");
            String name = sc.nextLine();

            System.out.print("Enter capacity: ");
            int capacity = sc.nextInt();

            Resource r = new Resource();
            r.resourceName = name;
            r.capacity = capacity;

            new ResourceDAO().createResource(r.resourceName, r.capacity);
            System.out.println("Resource created successfully.");

        } catch (Exception e) {
            System.out.println("Error creating resource.");
        }
    }

    // -------- BOOK RESOURCE --------
    static void bookResource() {
        try {
            System.out.print("Enter user ID: ");
            int userId = sc.nextInt();

            System.out.print("Enter resource ID: ");
            int resourceId = sc.nextInt();

            // Simplified time entry for CLI demo (Hours from "Now")
            System.out.print("Enter start time (hours from now): ");
            int startHr = sc.nextInt();

            System.out.print("Enter end time (hours from now): ");
            int endHr = sc.nextInt();

            // Calculate actual timestamps
            LocalDateTime start = LocalDateTime.now().plusHours(startHr);
            LocalDateTime end = LocalDateTime.now().plusHours(endHr);

            // Delegate logic to Service Layer
            new BookingService().bookResource(userId, resourceId, start, end);
            System.out.println("Booking request processed.");

        } catch (Exception e) {
            System.out.println("Error processing booking.");
        }
    }
}