package dao;

import java.sql.*;
import model.User;

/**
 * Handles database operations for User entities.
 */
public class UserDAO {

    /**
     * Inserts a new user into the database.
     * @param u The User object containing details to save.
     */
    public void createUser(User u) throws Exception {
        // 1. Get connection
        Connection c = DBConnection.getConnection();

        // 2. Prepare SQL statement (Prevents SQL Injection)
        PreparedStatement ps = c.prepareStatement(
              "INSERT INTO users(name, role, priority_score, penalty_points) VALUES(?,?,?,?)");

        // 3. Bind parameters
        ps.setString(1, u.name);
        ps.setString(2, u.role);
        ps.setInt(3, u.priorityScore);
        ps.setInt(4, u.penaltyPoints);

        // 4. Execute update
        ps.executeUpdate();

        // 5. Close connection to free resources
        c.close();
    }
}