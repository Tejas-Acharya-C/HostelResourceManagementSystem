package dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Utility class to handle Database Connectivity.
 * Uses the Singleton pattern concept (though implemented statically here) to provide connections.
 */
public class DBConnection {

    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/hostel_resource_db";
    private static final String USER = "root";
    private static final String PASSWORD = "12345678987"; // Ensure this matches your local MySQL setup

    /**
     * Establishes and returns a connection to the database.
     * @return Connection object
     * @throws Exception if driver not found or connection fails
     */
    public static Connection getConnection() throws Exception {
        // DriverManager automatically loads the driver in newer Java/JDBC versions
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}