package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Booking;

/**
 * Handles database operations for Bookings.
 * Note: Methods here accept a 'Connection' object to support Transaction Management
 * controlled by the Service layer.
 */
public class BookingDAO {

    /**
     * OLD METHOD: Retrieves a list of conflicting bookings.
     * Can be used if we need to show the user *which* bookings are blocking them.
     */
    public List<Booking> readConflicts(
        int resourceId, Timestamp start, Timestamp end, Connection c)
        throws Exception {

        // Logic: A conflict exists if a confirmed booking starts before our end
        // AND ends after our start.
        PreparedStatement ps = c.prepareStatement(
            "SELECT * FROM bookings WHERE resource_id=? AND status='CONFIRMED' " +
            "AND start_time < ? AND end_time > ?");

        ps.setInt(1, resourceId);
        ps.setTimestamp(2, end);   // Overlap check part 1
        ps.setTimestamp(3, start); // Overlap check part 2

        ResultSet rs = ps.executeQuery();
        List<Booking> list = new ArrayList<>();

        while (rs.next()) {
            Booking b = new Booking();
            b.bookingId = rs.getInt("booking_id");
            b.userId = rs.getInt("user_id");
            list.add(b);
        }
        return list;
    }

    /**
     * ✅ NEW METHOD — CORE OF CAPACITY LOGIC
     * Returns the count of overlapping, confirmed bookings for a time slot.
     */
    public int countActiveBookings(
        int resourceId, Timestamp start, Timestamp end, Connection c)
        throws Exception {

        // SQL Logic: Count rows where resource matches, status is confirmed,
        // and time overlaps with the requested start/end.
        PreparedStatement ps = c.prepareStatement(
            "SELECT COUNT(*) FROM bookings " +
            "WHERE resource_id=? AND status='CONFIRMED' " +
            "AND start_time < ? AND end_time > ?");

        ps.setInt(1, resourceId);
        ps.setTimestamp(2, end);   // Check if existing start is before requested end
        ps.setTimestamp(3, start); // Check if existing end is after requested start

        ResultSet rs = ps.executeQuery();
        rs.next(); // Move to the count result
        return rs.getInt(1);
    }

    /**
     * Inserts the booking record into the database.
     */
    public void createBooking(Booking b, Connection c) throws Exception {
        PreparedStatement ps = c.prepareStatement(
            "INSERT INTO bookings(user_id, resource_id, start_time, end_time, status) " +
            "VALUES (?, ?, ?, ?, ?)");

        ps.setInt(1, b.userId);
        ps.setInt(2, b.resourceId);
        // Convert LocalDateTime to SQL Timestamp
        ps.setTimestamp(3, Timestamp.valueOf(b.startTime));
        ps.setTimestamp(4, Timestamp.valueOf(b.endTime));
        ps.setString(5, b.status);

        ps.executeUpdate();
    }

    /**
     * Updates the status of a booking (e.g., CONFIRMED -> CANCELLED).
     */
    public void updateStatus(int bookingId, String status, Connection c)
        throws Exception {

        PreparedStatement ps =
            c.prepareStatement("UPDATE bookings SET status=? WHERE booking_id=?");

        ps.setString(1, status);
        ps.setInt(2, bookingId);
        ps.executeUpdate();
    }
}