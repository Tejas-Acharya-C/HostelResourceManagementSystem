package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Handles database operations for Resources (rooms, equipment).
 */
public class ResourceDAO {

    /**
     * Create a new resource in the database.
     * @param name Name of the resource
     * @param capacity How many people can use it at once
     */
    public void createResource(String name, int capacity) throws Exception {
        Connection c = DBConnection.getConnection();

        PreparedStatement ps = c.prepareStatement(
            "INSERT INTO resources(resource_name, capacity) VALUES (?, ?)");

        ps.setString(1, name);
        ps.setInt(2, capacity);
        ps.executeUpdate();

        c.close();
    }

    /**
     * Fetches the maximum capacity of a specific resource.
     * Crucial for logic determining if a booking can proceed.
     * @param resourceId The ID of the resource
     * @return The integer capacity
     */
    public int getCapacity(int resourceId) throws Exception {
        Connection c = DBConnection.getConnection();

        PreparedStatement ps =
            c.prepareStatement("SELECT capacity FROM resources WHERE resource_id=?");

        ps.setInt(1, resourceId);
        ResultSet rs = ps.executeQuery();

        // Move cursor to first row
        rs.next();

        int capacity = rs.getInt("capacity");
        c.close();

        return capacity;
    }
}